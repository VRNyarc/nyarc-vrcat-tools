# Core Framework Module
# Provides base classes, utilities, and registration system for NYARC VRChat Tools